**NodeJS APP**
===============================================

- - -


CONTENTS
---------

ABOUT NodeJS APP 
----------------------------------


CONFIGURATION AND INSTALLATION
-------------------------------

Download the zip from the jsonworld.com

 - Extract the code from downloaded zip
 - Change the config settings like database connection or any credentials needed.
 - Import data(file with .sql extension) from the root folder, if needed in the demo.
 - Install Node package dependencies using  ``npm install``
 - Develop or modify changes
 - Build and run it into the browser using ``npm start`` command

MORE INFORMATION
----------------

